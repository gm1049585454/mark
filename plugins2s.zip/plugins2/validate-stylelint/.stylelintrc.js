module.exports = {
  "extends": "stylelint-config-recommended",
  "rules":{
      "unit-no-unknown": false
  }
}