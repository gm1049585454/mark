const stylusSupremacy = require('stylus-supremacy')

function format(options){
	var _options = require("./supremacy.config.js")
	if (!options.useTabs && options.tabWidth && options.tabWidth > 0) {
		let spaces = " ";
		spaces = spaces.repeat(options.tabWidth);
		_options.tabStopChar = spaces;
	}
	let formated = stylusSupremacy.format(options.contents, _options)
	return formated;
}

module.exports = {
	format:format
}