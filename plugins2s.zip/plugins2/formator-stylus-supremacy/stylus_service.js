/**
 * 命令行接口
 * 输入参数：--range-start -1 --range-end -1 --stdin-filepath %path% --use-tabs true --tab-width 4
 * 输出：格式化后的内容
 */
const formator = require('./index.js')
const fs = require("fs")
const path = require("path")
// 截取参数 --range-start -1 --range-end -1 --stdin-filepath %path% 
var args = process.argv.slice(2)
var formator_options = {}
for (var i = 0; i < args.length; i = i + 2) {
	formator_options[args[i]] = args[i + 1]
}
var options = {
	start: parseInt(formator_options["--range-start"]),
	end: parseInt(formator_options["--range-end"]),
	filepath: formator_options["--stdin-filepath"],
	useTabs: "true" == formator_options["--use-tabs"],
	tabWidth: parseInt(formator_options["--tab-width"]),
	contents: fs.readFileSync(formator_options["--stdin-filepath"], "utf8")
}
if (!options.filepath || options.filepath.length == 0) {
	console.error("无效的参数：--stdin-filepath")
	process.exit(0)
}

if (options.start >= 0) {
	let formated = formator.format(options);
	console.log(formated.trim())
}
