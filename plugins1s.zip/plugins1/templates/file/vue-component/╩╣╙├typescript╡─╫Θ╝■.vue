<template>
	<view>

	</view>
</template>

<script lang="ts">
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style>

</style>
