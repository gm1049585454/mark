/**
 * 命令行接口
 * 输入参数：--range-start -1 --range-end -1 --stdin-filepath %path% --use-tabs true --tab-width 4
 * 输出：格式化后的内容
 */
const prettier = require("prettier")
const fs = require("fs")
const path = require("path")
// 截取参数 --range-start -1 --range-end -1 --stdin-filepath %path% 
var args = process.argv.slice(2)
var formator_options = {}
for (var i = 0; i < args.length; i = i + 2) {
	formator_options[args[i]] = args[i + 1]
}
var options = {
	start: parseInt(formator_options["--range-start"]),
	end: parseInt(formator_options["--range-end"]),
	filepath: formator_options["--stdin-filepath"],
	useTabs: "true" == formator_options["--use-tabs"],
	tabWidth: parseInt(formator_options["--tab-width"]),
	contents: fs.readFileSync(formator_options["--stdin-filepath"], "utf8")
}
if (!options.filepath || options.filepath.length == 0) {
	console.error("无效的参数：--stdin-filepath")
	process.exit(0)
}

if (options.start >= 0) {
	var _options = require("./prettier.config.js")
	var extname = path.extname(options.filepath)
	if (_options.parsers) {;
		(_options.parser = _options.parsers[extname] ? _options.parsers[extname] : "flow"),
		delete _options.parsers
	}
	if (options.tabWidth && options.tabWidth > 0) {
		_options.useTabs = options.useTabs;
		_options.tabWidth = options.tabWidth;
	}
	let formated_contents = null;
	if (options.end > options.start) {
		_options.rangeStart = options.start
		_options.rangeEnd = options.end
		let formated = prettier.format(options.contents, _options)
		formated_contents = formated.trim();
	} else {
		let result = prettier.format(options.contents, _options)
		formated_contents = result.trim();
	}
	//handle stylus
	if(_options.parser == "vue" && formated_contents){
		let styleStartIndex = formated_contents.indexOf("<style ");
		if(styleStartIndex != -1){
			let maxLen = Math.min(formated_contents.length,styleStartIndex + 200);
			for(let i = styleStartIndex;i < maxLen;i++){
				let end = formated_contents.charAt(i);
				if (end == '>') {
					let styleBeginTagContent = formated_contents.substring(styleStartIndex,i + 1);
					if(/lang\s*=\s*["']stylus["']/.test(styleBeginTagContent)){
						let styleEndIndex = formated_contents.indexOf("</style");
						if(styleEndIndex != -1){
							let stylusContents = formated_contents.substring(i+1,styleEndIndex);
							if(fs.existsSync("../formator-stylus-supremacy/index.js")){
								let stylusFormator = require('../formator-stylus-supremacy/index.js')
								options.contents = stylusContents.trim();
								let stylusFormatedContents = stylusFormator.format(options);
								formated_contents = formated_contents.substring(0,i+1) + "\n"
								+ stylusFormatedContents.trim() + "\n"
								+ formated_contents.substr(styleEndIndex);
							}
						}
					}
					break;
				}
			}
		}
	}
	if(formated_contents){
		console.log(formated_contents);
	}
}
