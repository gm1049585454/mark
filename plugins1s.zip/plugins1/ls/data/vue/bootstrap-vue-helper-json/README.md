# bootstrap-vue-helper-json

Bootstrap-Vue/Vetur intellisense reference definitions.
