# element-helper-json
Making IDE / test editor plugin development easier
