# buefy-helper-json

Definitions of Buefy components for Vetur
