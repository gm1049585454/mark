# gridsome-helper-json
Information to enhance [Vetur](https://github.com/vuejs/vetur)'s auto completion for [Gridsome](https://github.com/gridsome/gridsome).

## License
MIT

## Inspired by
[nuxt-helper-json](https://github.com/nuxt-community/nuxt-helper-json)