## 1.0.0 (2019-02-19)

##### Refactors

*  Remove page-query and static-query in tags.json ([d72408ac](https://github.com/tyankatsu0105/gridsome-helper-json/commit/d72408ac0c2e6e6f5161d9620438aba967c3f2bd))

#### 0.1.2 (2019-02-18)

##### Bug Fixes

*  Rename file ([6b5cde83](https://github.com/tyankatsu0105/gridsome-helper-json/commit/6b5cde835322e63df808f8fa5c605986f5e0ec0f))

#### 0.1.1 (2019-02-18)

##### Refactors

*  Refactor test script command ([1d0bcce6](https://github.com/tyankatsu0105/gridsome-helper-json/commit/1d0bcce68457b64801c8cee3b022059794476ad4))

### 0.1.0 (2019-02-18)

##### Build System / Dependencies

*  Change changelog url ([bf1d123c](https://github.com/tyankatsu0105/gridsome-helper-json/commit/bf1d123ceacc0d7a79cb1eabdcbe76c143c40848))

##### Continuous Integration

*  Settings Travis CI config ([218b3c38](https://github.com/tyankatsu0105/gridsome-helper-json/commit/218b3c381ec7864201ec6defc994c54621a64744))

##### Documentation Changes

*  Refactor README.md ([05736416](https://github.com/tyankatsu0105/gridsome-helper-json/commit/057364164d3b8aa2c6ad5e633e4a7ca6a49d942e))

##### New Features

*  Add attributes and tags used by Gridsome ([7c67a3ba](https://github.com/tyankatsu0105/gridsome-helper-json/commit/7c67a3baf8767b4bc0c26d323d3493ff8d2b4e8d))
*  Add all property and tag used by Gridsome ([70b4fd40](https://github.com/tyankatsu0105/gridsome-helper-json/commit/70b4fd40e8409c79996be4d84a2111276bbe95ea))
*  Add necessary files ([2dc60d34](https://github.com/tyankatsu0105/gridsome-helper-json/commit/2dc60d348545b7cc5df9261521d1d68f4eb1a1dc))

