CHANGELOG
====

v1.0.0
----

 * Initial version of this package.
 * Supported `onsenui@2.4.2` and `vue-onsenui@2.0.0`.
