# vue-onsenui-helper-json

Tags and attributes information of `vue-onsenui`, which makes IDE / test editor plugin development easier.

This NPM package is maintained in the following directory in [OnsenUI/OnsenUI](https://github.com/OnsenUI/OnsenUI):  
https://github.com/OnsenUI/OnsenUI/tree/master/bindings/vue/packages/vue-onsenui-helper-json

## Supported Environments

- [Vetur](https://github.com/vuejs/vetur)
