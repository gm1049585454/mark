# SVN使用教程

windows svn： [windows svn教程](http://ask.dcloud.net.cn/article/35246)

mac svn： [mac svn教程](http://ask.dcloud.net.cn/article/35252)

### SVN插件配置

1. 点击菜单【工具】-->【外部命令】-->【svn插件】-->【插件配置】
2. 关于插件配置文件package.json

```
{
    "id":"SVN_CHECKOUT",    //命令ID
    "name":"svn checkout 检出",   //外部命令显示名称
    "command":["${programPath}", "/command:checkout"],    //执行的命令，${programPath}表示检测到的可执行程序的路径
    "key":"",   //快捷键
    "showInParentMenu":false, //是否显示在上一级菜单中
    "onDidSaveExecution": false,  //是否保存时执行
    "isBackground": true
}
```

备注：修改配置文件后，重启HBuilderX才能生效